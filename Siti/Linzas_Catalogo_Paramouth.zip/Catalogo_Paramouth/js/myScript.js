$(document).ready(function() {
    $('#btn-film').on("click", function() {
        $('#aggiunta').toggle();
    })


})

alert("prova");